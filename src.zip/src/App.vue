<template>
  <div id="app">
    <RichText />
  </div>
</template>

<script>
import RichText from './components/RichText.vue'

export default {
  name: 'App',
  components: {
    RichText
  }
}
</script>

<style>

</style>
