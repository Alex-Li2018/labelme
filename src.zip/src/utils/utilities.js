export function clamp(x, min, max) {
    return Math.min(max, Math.max(min, x));
}